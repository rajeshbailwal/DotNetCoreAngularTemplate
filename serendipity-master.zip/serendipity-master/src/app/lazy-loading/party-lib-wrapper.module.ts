import { NgModule } from '@angular/core';

import { PartyModule } from 'party';

@NgModule({
  imports: [ PartyModule ]
})
export class PartyLibWrapperModule {}

