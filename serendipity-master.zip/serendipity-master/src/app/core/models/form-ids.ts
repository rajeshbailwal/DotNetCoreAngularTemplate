// export const PROFILE_GENERAL_INFORMATION_GROUP = 'profile-general-information-form';
export const PROFILE_GENERAL_INFORMATION_GROUP = 'profile-general-information-form-read-only';
export const PROFILE_ADDRESS_INFORMATION_GROUP = 'profile-address-information-form';
