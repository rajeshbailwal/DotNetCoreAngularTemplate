export const SalesConfigService = 'Sales Config';
