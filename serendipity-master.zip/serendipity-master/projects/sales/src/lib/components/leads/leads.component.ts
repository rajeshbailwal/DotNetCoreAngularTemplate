import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sales-leads',
  templateUrl: './leads.component.html',
  styleUrls: ['./leads.component.scss']
})
export class LeadsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
