/*
 * Public API Surface of sales
 */

export * from './lib/components/opportunities/opportunities.component';
export * from './lib/components/leads/leads.component';

export * from './lib/models/config';

export * from './lib/sales.module';
