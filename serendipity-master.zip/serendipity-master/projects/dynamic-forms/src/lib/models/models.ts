import { Config } from 'utils';

// tslint:disable-next-line:no-empty-interface
export interface DynamicFormsConfig extends Config {}

export * from '../angular-material/models/dynamic-form.model';
export * from '../angular-material/models/dynamic-form-control.model';
