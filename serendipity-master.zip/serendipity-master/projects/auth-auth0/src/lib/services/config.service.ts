export const Auth0ConfigService = 'Auth0 Config';
