export abstract class Logger {

  public info: any;
  public warn: any;
  public error: any;

}
