export const WorkConfigService = 'Work Config';
