/*
 * Public API Surface of work
 */

export * from './lib/components/activities/activities.component';
// export * from './lib/components/dashboard/dashboard.component';
export * from  './lib/components/email/email.component';
export * from  './lib/components/tasks/tasks.component';

export * from './lib/work.module';
