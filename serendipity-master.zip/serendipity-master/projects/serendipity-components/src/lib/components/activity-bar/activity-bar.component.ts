import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'crm-activity-bar',
  templateUrl: './activity-bar.component.html',
  styleUrls: ['./activity-bar.component.scss']
})
export class ActivityBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
