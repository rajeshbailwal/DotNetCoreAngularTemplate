export interface ColumnDef {
  name?: string;
  displayName?: string;
  routerLink?: string;
  class?: string;
}
