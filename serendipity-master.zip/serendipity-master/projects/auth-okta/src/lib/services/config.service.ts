export const OktaConfigService = 'Okta Config';
