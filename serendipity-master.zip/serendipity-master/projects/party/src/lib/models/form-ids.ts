export const ACCOUNT_GENERAL_INFORMATION_GROUP = 'account-general-information-form';

export const CONTACT_GENERAL_INFORMATION_GROUP = 'contact-general-information-form-with-avatar';
export const CONTACT_ADDRESS_INFORMATION_GROUP = 'contact-address-information-form';

export const EMAIL_GROUP = 'email-form';
