import { Individual } from './individual';

// tslint:disable-next-line:no-empty-interface
// export interface Contact extends Individual {}
export class Contact extends Individual {}
