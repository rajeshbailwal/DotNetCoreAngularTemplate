export class IndividualRef {

  constructor(
    public id: string = '',
    public displayName: string = '',
    public email: string = '',
    public phoneNumber: string = ''
  ) {}

}
